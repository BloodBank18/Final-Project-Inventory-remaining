use Training_19Sep18_Pune


alter proc BBank.uspVerifyBloodBankID
(
--Check if Blood Bank Id already exists in Blood Bank table
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbID varchar(50)
)
as 
begin 
	select count(*) from BBank.BloodBank where BloodBankID=@bbID
end 



alter proc BBank.uspAddBloodBankDetails
(
--Insert details into blood bank table with user name and password
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint,
@bbUserID varchar(50),
@bbPassword binary(50)
)
as
begin
	insert into BBank.BloodBank values
(@bbID,
@bbName,
@bbAddress,
@bbCity,
@bbContactNo,
@bbUserID,
@bbPassword) 
end

alter proc BBank.uspAddBloodBankDetails2
(
--Insert details into blood bank table without user name and password
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint
)
as
begin
	insert into BBank.BloodBank
(BloodBankID,
BloodBankName,
Address,
City,
ContactNumber) values
(@bbID,
@bbName,
@bbAddress,
@bbCity,
@bbContactNo
) 
end

alter proc BBank.uspDisplayAllBloodBankDetails
--Display all Blood Bank details available in Blood Bank Table
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
as
begin
select BloodBankID,BloodBankName,Address,City,ContactNumber from BBank.BloodBank
end

alter proc BBank.uspUserLogin
(
--Obtain password of user 
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbUserID varchar(50)
)
as
begin
	select Password from BBank.BloodBank
	where UserID=@bbUserID
end
select * from BBank.BloodBank
delete from BBank.BloodBank where BloodBankId='BB99999'
Insert into BBank.BloodBank values('BB99998','blood','shivaji chowk','pune',7788996654,'admin1','admin1')

alter proc BBank.uspSearchForDuplicateUser
(
--Check if username exists in blood bank table
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbUserID varchar(50)
)
as 
begin
	select count(*) from BBank.BloodBank where UserID=@bbUserID
end

alter proc BBank.uspUpdateBloodBankDetails
(
--Update details in blood bank table
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint
)
as
begin
	update BBank.BloodBank set BloodBankName=@bbName,
	Address=@bbAddress,
	City=@bbCity,
	ContactNumber=@bbContactNo
	where
	BloodBankID=@bbID
end

create proc BBank.uspBloodBankID
as
begin
	select BloodBankID from BBank.BloodBank
--Obtain Blood Bank ID from Blood Bank table to populate combo box
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
end


create proc BBank.uspSearchBloodBankDetails
(
--Search for Blood bank details and return the data if it is found
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbID varchar(50)
)
as
begin
	select BloodBankName,
	Address,
	City,
	ContactNumber from BBank.BloodBank where BloodBankID=@bbID
end

create proc BBank.uspDeleteBloodBankDetails
(
--Delete details from blood bank table with the specified Id
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@bbID varchar(50)
)
as 
begin
	delete from BBank.BloodBank where BloodBankID=@bbID
end

--=================================================================================

create proc BBank.uspVerifyHospitalID
(
--Check if Hospital Id already exists in Blood Bank table
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@hID varchar(50)
)
as 
begin 
	select count(*) from BBank.Hospital where HospitalID=@hID
end 

create proc BBank.uspAddHospitalDetails
(
--Insert details into hospital table 
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@hID varchar(50),
@hName varchar(50),
@hAddress varchar(50),
@hCity varchar(50),
@hContactNo bigint
)
as
begin
	insert into BBank.Hospital
(HospitalID,
HospitalName,
Address,
City,
ContactNumber) values
(@hID,
@hName,
@hAddress,
@hCity,
@hContactNo
) 
end

select * from BBank.Hospital

create proc BBank.uspDisplayAllHospitalDetails
as
begin
--Display all Hospital details available in Hospital Table
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
select HospitalID,HospitalName,Address,City,ContactNumber from BBank.Hospital
end


create proc BBank.uspHospitalID
as
begin
--Obtain Hospital ID from Hospital table to populate combo box
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
	select HospitalID from BBank.Hospital
end


alter proc BBank.uspSearchHospitalDetails
(
--Search for Hospital details and return the data if it is found
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@hID varchar(50)
)
as
begin
	select HospitalName,
	Address,
	City,
	ContactNumber from BBank.Hospital where HospitalID=@hID
end

create proc BBank.uspUpdateHospitalDetails
(
--Update details in hospital table
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@hID varchar(50),
@hName varchar(50),
@hAddress varchar(50),
@hCity varchar(50),
@hContactNo bigint
)
as
begin
	update BBank.Hospital set HospitalName=@hName,
	Address=@hAddress,
	City=@hCity,
	ContactNumber=@hContactNo
	where
	HospitalID=@hID
end

create proc BBank.uspDeleteHospitalDetails
(
--Delete details from hospital table with the specified Id
--Developed by:Soumick Ghosh
--Last modified:29/11/2018
@hID varchar(50)
)
as 
begin
	delete from BBank.Hospital where HospitalID=@hID
end

--===============================================================================
