﻿using BloodBankMangementSystem.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BloodBankManagementSystem.UI
{
    /// <summary>
    /// Interaction logic for BloodTransfer.xaml
    /// </summary>
    public partial class BloodTransfer : Window
    {
        public BloodTransfer()
        {
            InitializeComponent();
        }

        

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllBloodBankName();
            //bloodgroupcomboBox.Items.Add("A+");
            //bloodgroupcomboBox.Items.Add("A-");
            //bloodgroupcomboBox.Items.Add("B+");
            //bloodgroupcomboBox.Items.Add("B-");
            //bloodgroupcomboBox.Items.Add("O+");
            //bloodgroupcomboBox.Items.Add("O-");
            //bloodgroupcomboBox.Items.Add("AB+");
            //bloodgroupcomboBox.Items.Add("AB-");
        }


        public void GetAllBloodBankName()
        {
            BloodInventoryBLL bi = new BloodInventoryBLL();
            DataTable bloodBankName = bi.GetAllBloodBankName();
            if (bloodBankName == null)
            {
                MessageBox.Show("nothing to show");
            }
            else
            {
                string[] result = new string[bloodBankName.Rows.Count];


                for (int i = 0; i < bloodBankName.Rows.Count; i++)
                {
                    for (int j = 0; j < bloodBankName.Columns.Count; j++)
                    {
                        result[i] = bloodBankName.Rows[i][j].ToString();
                        cmbFrom.Items.Remove(result[i]);
                        cmbTo.Items.Remove(result[i]);
                    }
                }
                for (int i = 0; i < bloodBankName.Rows.Count; i++)
                {
                    for (int j = 0; j < bloodBankName.Columns.Count; j++)
                    {
                        result[i] = bloodBankName.Rows[i][j].ToString();
                        cmbFrom.Items.Add(result[i]);
                        cmbTo.Items.Add(result[i]);
                    }
                }
            }

        }

        private void CmbFrom_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            string selectedItem = cmbFrom.SelectedItem.ToString();
            cmbTo.Items.Remove(selectedItem);

            BloodInventoryBLL bll = new BloodInventoryBLL();
            DataTable dt = bll.GetRespectiveBloodGroup(selectedItem);

            if (dt == null)
            {
                MessageBox.Show("Nothing To Show!!");
            }
            else
            {
                string[] result = new string[dt.Rows.Count];


                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        result[i] = dt.Rows[i][j].ToString();
                        bloodgroupcomboBox.Items.Remove(result[i]);
                        
                    }
                }
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        result[i] = dt.Rows[i][j].ToString();
                        bloodgroupcomboBox.Items.Add(result[i]);
                        
                    }
                }
            }



        }

        private void CmbTo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedItem = cmbFrom.SelectedItem.ToString();
            //CmbFrom_SelectionChanged(sender,e);
            cmbTo.Items.Add(selectedItem);
            cmbTo.Items.Refresh();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string FromBloodBank = cmbFrom.SelectedItem.ToString();
            string ToBloodBank = cmbTo.SelectedItem.ToString();
            int NoofBottles = int.Parse(noofbottlestextBox.Text);
            string bloodGroup = bloodgroupcomboBox.SelectedItem.ToString();
            BloodInventoryBLL b = new BloodInventoryBLL();
           int a = b.TransferBlood(FromBloodBank, ToBloodBank, NoofBottles, bloodGroup);

            if(a>0)
            {
                MessageBox.Show("Blood Transfered Sucessfull");
            }
        }
    }
}
