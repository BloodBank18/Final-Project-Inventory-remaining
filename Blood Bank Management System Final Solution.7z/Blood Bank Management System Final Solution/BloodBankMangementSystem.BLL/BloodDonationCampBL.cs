﻿using BloodBankMangementSystem.DAL;
using BloodBankMangementSystem.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BloodBankMangementSystem.BLL
{
    public class BloodDonationCampBL
    {
        BloodDonationCampDL bbDL = new BloodDonationCampDL();
        StringBuilder sb = new StringBuilder();


        //Method to validate BloodDonationCampAdd.xaml window
        //Developed By: Bhakti Patil
        //Last modified date: 29/11/2018
        public bool validateCampIdArrange(string BloodDonationCampId)
        {
            bool valid = true;
            if (bbDL.VerifyBloodDonationCampID(BloodDonationCampId) == 1)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID already exists");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }
        //Method to validate BloodDonationCampModify.xaml window
        //Developed By: Bhakti Patil
        //Last modified date: 29/11/2018
        public bool validateCampIdModify(string BloodDonationCampId)
        {
            bool valid = true;
            if (bbDL.VerifyBloodDonationCampID(BloodDonationCampId) == 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID not found");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }


        //Method to validate BloodDonationCampDelete.xaml window
        //Developed By: Bhakti Patil
        //Last modified date: 29/11/2018
        public bool validateCampIdDelete(string BloodDonationCampId)
        {
            Regex r1 = new Regex("^[D]{1}[C]{1}[0-9]{5}$");
            bool valid = true;
            if (BloodDonationCampId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID cannot be empty\nID must be in the format DC12345");
            }
            else if (!r1.IsMatch(BloodDonationCampId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID is not valid\nID must be in the format DC12345");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }


        //Method to validate BloodDonationCampModify.xaml and BloodDonationCampAdd.xaml window
        //Developed By: Bhakti Patil
        //Last modified date: 29/11/2018
        public bool ValidateBloodDonationCampData(string BloodDonationCampId, string CampName, string Address, string City, string BloodBankId, string CampStartDate, string CampEndDate)
        {
            Regex r1 = new Regex("^[D]{1}[C]{1}[0-9]{5}$");
            Regex r2 = new Regex("^[B]{1}[B]{1}[0-9]{5}$");

            bool valid = true;
            if (BloodDonationCampId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID cannot be empty\nID must be in the format DC12345");
            }
            else if (!r1.IsMatch(BloodDonationCampId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID is not valid\nID must be in the format DC12345");
            }

            if (CampName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp Name cannot be empty");
            }
            if (BloodBankId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Bank Id cannot be empty\nID must be in the format BB12345");
            }
            else if (!r2.IsMatch(BloodBankId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Bank Id is not in proper format\nID must be in the format BB12345");
            }
            if (Address == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nAddress cannot be empty");
            }
            if (City == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCity cannot be empty");
            }
            if (Convert.ToDateTime(CampStartDate) > Convert.ToDateTime(CampEndDate))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCamp start date cannot be greater than Camp end date");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }


        //Method to call ArrangeCampDAL method in BloodDonationCampDL
        //Developed By: Vijayalaxmi T.
        //Last modified date: 29/11/2018
        public bool ArrangeCampBLL(BloodDonationCamp arrange)
        {
            bool arrangeCamp = false;
            try
            {
                BloodDonationCampDL bBMSDAL = new BloodDonationCampDL();
                arrangeCamp = bBMSDAL.ArrangeCampDAL(arrange);
            }
            catch
            {
                throw;
            }

            return arrangeCamp;
        }

        //Method to call ViewCampDetailsDAL method in BloodDonationCampDL
        //Developed By: Vijayalaxmi T.
        //Last modified date: 29/11/2018
        public DataTable ViewCampDetailsBLL()
        {
            try
            {
                BloodDonationCampDL bBMSDAL = new BloodDonationCampDL();
                return bBMSDAL.ViewCampDetailsDAL();
            }
            catch
            {
                throw;
            }
        }

        //Method to call ModifyCampDAL method in BloodDonationCampDL
        //Developed By:Kalyani Wakchaure
        //Last modified date: 29/11/2018
        public bool ModifyCampBLL(BloodDonationCamp modify)
        {
            try
            {
                BloodDonationCampDL bd = new BloodDonationCampDL();
                return bd.ModifyCampDAL(modify);
            }
            catch
            {
                throw;
            }
        }

        //Method to call DeleteCampDAL method in BloodDonationCampDL
        //Developed By:Kalyani Wakchaure
        //Last modified date: 29/11/2018
        public bool DeleteCampBLL(string bloodDonationCampID)
        {
            try
            {
                BloodDonationCampDL bd = new BloodDonationCampDL();
                return bd.DeleteCampDAL(bloodDonationCampID);
            }
            catch
            {
                throw;
            }
        }


        //Method to call SearchCampDAL method in BloodDonationCampDL
        //Developed By:Kalyani Wakchaure
        //Last modified date: 29/11/2018
        public BloodDonationCamp SearchCampBLL(string bloodDonationCampID)
        {
            try
            {
                BloodDonationCampDL bd = new BloodDonationCampDL();
                return bd.SearchCampDAL(bloodDonationCampID);
            }
            catch
            {
                throw;
            }
        }
    }
}
