﻿using BloodBankMangementSystem.DAL;
using BloodBankMangementSystem.Entity;
using BloodBankMangementSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankMangementSystem.BLL
{
   public class BloodInventoryBLL
    {
        //Display Inventory Details
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public DataTable BloodInventoryDisplay()
        {
            try
            {
                BloodInventoryDL bid = new BloodInventoryDL();
                return bid.BloodInventoryDisplay();
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Delete Inventory Details
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public bool DeleteBloodInventory(DateTime ExpiryDate)
        {
            try
            {
                BloodInventoryDL bid = new BloodInventoryDL();
                return bid.DeleteBloodInventory(ExpiryDate);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Update Inventory Details
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public bool EditBloodInventory(BloodInventory pobj)
        {
            try
            {
                BloodInventoryDL pd = new BloodInventoryDL();
                return pd.EditBloodInventory(pobj);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Take all blood bank names from database
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public DataTable GetAllBloodBankName()
        {
            BloodInventoryDL bid = new BloodInventoryDL();
            return bid.GetAllBloodBankName();
        }

        //Search Inventory Details by Inventory ID
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public BloodInventory Search(int searchInventory)
        {
            try
            {
                BloodInventoryDL pd = new BloodInventoryDL();
                return pd.Search(searchInventory);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //transfer blood froom one bank to other bank
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public int TransferBlood(string fromBloodBank, string toBloodBank, int noofBottles,string bloodGroup)
        {
            try
            {
                BloodInventoryDL pd = new BloodInventoryDL();
                return pd.TransferBlood(fromBloodBank, toBloodBank, noofBottles, bloodGroup);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Get BloodGroup details for transfer
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public DataTable GetRespectiveBloodGroup(string selectedItem)
        {
            try
            {
                BloodInventoryDL dl = new BloodInventoryDL();
                return dl.GetRespectiveBloodGroup(selectedItem);
            }
            catch (Exception)
            {

                throw;
            }
            
        }
        
        //Developed by:Suvajit Sahoo
        //Last modified:29/11/2018
        public bool ValidateTransferData_FromBloodBank(object FromBloodBank)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                bool valid = true;
                if(FromBloodBank==null)
                {
                    valid = false;
                    sb.Append(Environment.NewLine + "\nSelect Blood Bank from where blood must be transferred from");
                }
                if (valid == false)
                    throw new BloodBankExceptions(sb.ToString());
                return valid;
            }
            catch(Exception)
            {
                throw;
            }
        }

        public bool ValidateTransferData_ToBloodBank_BloodGroup(object ToBloodBank, object BloodGroup)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                bool valid = true;
                if (ToBloodBank == null)
                {
                    valid = false;
                    sb.Append(Environment.NewLine + "\nSelect Blood Bank where blood must be transferred to");
                }
                if(BloodGroup==null)
                {
                    valid = false;
                    sb.Append(Environment.NewLine + "\nSelect Blood Group");
                }
                if (valid == false)
                    throw new BloodBankExceptions(sb.ToString());
                return valid;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

