﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBankMangementSystem.Exceptions;
using BloodBankMangementSystem.Entity;
using BloodBankMangementSystem.DAL;
using System.Data;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace BloodBankMangementSystem.BLL
{
   public  class DonorBL
    {
        //Method for Adding the Blood Donar
        //Developed By:Poonam Satghare
        //Last modified date: 29/11/2018
        public bool AddDonor(DonorEntities de)
        {
            try
            {

                BloodDonorDAL pdl = new BloodDonorDAL();
                return pdl.AddDonor(de);


            }
            catch (BloodBankExceptions)
            {

                throw;
            }
        }
        public DataTable GetBloodDonorId()
        {//Load Hospital ID In Combo Box
            try
            {
                BloodDonorDAL bbDL = new BloodDonorDAL();
                return bbDL.GetBloodDonorId();
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }

        //Method for validating the Blood Donar details
        //Developed By:Poonam Satghare
        //Last modified date: 29/11/2018
        public bool ValidateBloodDonorData(string BloodDonorID, string FirstName, string LastName, string Address, string City, string Mobile)
        {


            Regex r = new Regex("^[7-9]{1}[0-9]{9}$");

            Regex r2 = new Regex("^[B]{1}[D]{1}[0-9]{5}$");

            BloodDonorDAL bbDL = new BloodDonorDAL();

            StringBuilder sb = new StringBuilder();

            bool valid = true;
            if (BloodDonorID == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID cannot be empty\nID must be in the format BD12345");
            }
            else if (!r2.IsMatch(BloodDonorID))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID is not in proper format\nID must be in the format BD12345");
            }
            else if (bbDL.VerifyBloodDonorID(BloodDonorID) == 1)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID already exists");
            }

            if (FirstName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor First Name cannot be empty");
            }
            if (LastName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor Last Name cannot be empty");
            }
            if (Address == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nAddress cannot be empty");
            }
            if (City == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCity cannot be empty");
            }
            if (!r.IsMatch(Mobile))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nPhone number is not in proper format");
            }
            if (valid == false)
                throw new BloodBankExceptions(sb.ToString());
            return valid;
        }

        //Method to call ArrangeCampDAL method in BloodDonationCampDL
        //Developed By: Shanu Parasar.
        //Last modified date: 23/11/2018
        public DataTable GetAllBloodBankID()
        {
            BloodDonorDAL bid = new BloodDonorDAL();
            return bid.GetAllBloodBankID();
        }

        //Method for validating the Blood Donar Donation details
        //Developed By:Akhila G
        //Last modified date: 29/11/2018
        public bool ValidateBloodDonationDetails(string bloodDonerId, string date, string noofbottles, string weight, string hbc)
        {

            DonorBL bbBL = new DonorBL();
            DataTable dt = bbBL.GetBloodDonorId();
            Regex r = new Regex("^[7-9]{1}[0-9]{9}$");

            Regex r2 = new Regex("^[B]{1}[D]{1}[0-9]{5}$");

            BloodDonorDAL bbDL = new BloodDonorDAL();

            StringBuilder sb = new StringBuilder();

            bool valid = true;
            if (bloodDonerId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID cannot be empty\nID must be in the format BD12345");
            }
            else if (!r2.IsMatch(bloodDonerId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID is not in proper format\nID must be in the format BD12345");
            }



            if (dt != null)
            {
                foreach (DataRow t in dt.Rows)
                {
                    if (bloodDonerId == t["BloodDonerId"].ToString())
                    {
                        valid = true;
                        break;

                    }
                    else
                    {
                        valid = false;

                    }

                }


            }
            if (date.ToString() == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDate not selected");

            }
            if (noofbottles.ToString() == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Bottles not selected");

            }
            if (valid == false)
            {
                sb.Append(Environment.NewLine + "\nDonor ID doesn't exists");
            }

            if (weight.ToString() == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\n Check weight");
            }
            if (hbc.ToString() == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCheck HBC amount ");
            }

            //if ()
            //{
            //    valid = false;
            //    sb.Append(Environment.NewLine + "\nhbc amount should be number");
            //}
            if (valid == false)
                throw new BloodBankExceptions(sb.ToString());

            return valid;



        }

        //Method to call ArrangeCampDAL method in BloodDonationCampDL
        //Developed By: Shanu Parasar.
        //Last modified date: 27/11/2018
        public string GetBloodGroup(string DonorId)
        {
            BloodDonorDAL Bd = new BloodDonorDAL();
            return Bd.GetBloodGroup(DonorId);
        }

        //Method for adding details of Blood Donar Donation
        //Developed By:Akhila G
        //Last modified date: 29/11/2018
        public int AddDonation(BloodDonorDonations pobj)
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.AddDonation(pobj);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }


        
        //Method for Updating details of Blood Donar
        //Developed By:Dheeraj Patel
        //Last modified date: 29/11/2018
        public bool EditDonor(DonorEntities pobj)
        {
            BloodDonorDAL pd = new BloodDonorDAL();
            try
            {
                return pd.UpdateDonor(pobj);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        //Method for Delete details of Blood Donar
        //Developed By:Rahul Deshmukh
        //Last modified date: 29/11/2018
        public bool DeleteDonor(string donorId)
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.DeleteDonor(donorId);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        //Method for Searching details of Blood Donar
        //Developed By:Vaibhav Wadekar
        //Last modified date: 29/11/2018
        public DonorEntities Search(string donorId)
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.Search(donorId);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        //Method for Display details of Blood Donar
        //Developed By:Dheeraj Patel
        //Last modified date: 29/11/2018
        public DataTable Display()
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.Display();
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        //Method for getting details of Blood Groups
        //Developed By:Dheeraj Patel
        //Last modified date: 29/11/2018
        public DataTable GetCategories()
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.GetCategories();
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        //Method for displaying the Blood Donar Donation details
        //Developed By:Akhila G
        //Last modified date: 29/11/2018
        public DataTable DisplayDonations()
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.DisplayDonations();
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }
    }
}
