--stored procedure for AddDonationwithInventory
--Developed by:Rohith Shinde
--Last modified:29/11/2018
create proc BBank.uspAddDonationwithInventory
( 
@blooddonerid varchar(255),
@donationDate date, 
@noofbottle int,
@wt int,
@hbc decimal(15,2),
@BloodDonationId int out,
@BloodBankId varchar(255),
@BloodGroup varchar(50)
)
as
begin
	insert into BBank.BloodDonerDonation
	values(@blooddonerid,@donationDate,@noofbottle,@wt,@hbc)
	set @BloodDonationId  = Scope_Identity()

	

	insert into BBank.BloodInventory(BloodGroup,NumberofBottles,BloodBankID,ExpiryDate)
	values(@BloodGroup,@noofbottle,@BloodBankId,DATEADD(MONTH, 3, @donationDate))
end


select * from BBank.BloodDonerDonation

create proc BBank.BloodDonerDonation1
as
begin
select IDENT_CURRENT('BBank.BloodDonerDonation') +IDENT_Incr('BBank.BloodDonerDonation') 
end


create proc BBank.uspDisplayInventory
as
begin
select * from BBank.BloodInventory
end



Create table suva.Customer(
CustomerId int primary key,
Name varchar(50),
PhoneNo bigint

)

select * from suva.Customer