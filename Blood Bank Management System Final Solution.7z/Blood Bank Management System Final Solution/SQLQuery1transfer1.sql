

alter proc BBank.uspBloodTransfer
(
@bloodBankIDFrom varchar(50),
@bloodBankIDTo varchar(50),
@bloodGroup varchar(50),
@numberofBottles int
--@expiryDate Date
)
as
begin
update BBank.BloodInventory set  NumberofBottles=NumberofBottles-@numberofBottles where BloodBankID=@bloodBankIDFrom and BloodGroup=@bloodGroup


insert into BBank.BloodInventory (BloodGroup,NumberofBottles,BloodBankID,ExpiryDate)
values(@bloodGroup,@numberofBottles,@bloodBankIDTo,(Select ExpiryDate from BBank.BloodInventory where BloodBankID=@bloodBankIDFrom));

end

select * from BBank.BloodDonerDonation



alter proc BBank.uspGetAllName
as 
begin 
select distinct BloodBankID from BBank.BloodInventory
end

alter proc BBank.uspGetAllBloodGroup
(
@BloodBankIDFrom varchar(50)
)
as 
begin 
select distinct BloodGroup from BBank.BloodInventory where BloodBankID=@BloodBankIDFrom
end


select * from BBank.BloodBank

alter proc BBank.uspEditBloodInventory
(
@bId int,
@BloodGroup varchar(50),
@noofbottle int,
@BloodBankId varchar(50),
@expiryDate date
)
as
begin
update BBank.BloodInventory set NumberofBottles=@noofbottle, BloodGroup=@BloodGroup,ExpiryDate=@expiryDate, BloodBankID=@BloodBankId where BloodBankID=@BloodBankId
end

delete from BBank.BloodInventory

