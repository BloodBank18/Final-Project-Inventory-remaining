create database Shanu

alter proc uspBloodTransfer
(
@bloodBankIDFrom varchar(50),
@bloodBankIDTo varchar(50),
@bloodGroup varchar(50),
@numberofBottles int
--@expiryDate Date
)
as
begin
update BloodInventory set  NumberofBottles=NumberofBottles-@numberofBottles where BloodBankID=@bloodBankIDFrom and BloodGroup=@bloodGroup;

insert into BloodInventory (BloodGroup,NumberofBottles,BloodBankID,ExpiryDate)
values(@bloodGroup,@numberofBottles,@bloodBankIDTo,(Select ExpiryDate from BloodInventory where BloodBankID=@bloodBankIDFrom));

end

select * from BloodInventory


alter proc uspGetAllName
as 
begin 
select Distinct BloodBankID from BloodInventory
end

alter proc uspGetAllBloodGroup
(
@BloodBankIDFrom varchar(50)
)
as 
begin 
select distinct BloodGroup from BloodInventory where BloodBankID=@BloodBankIDFrom
end