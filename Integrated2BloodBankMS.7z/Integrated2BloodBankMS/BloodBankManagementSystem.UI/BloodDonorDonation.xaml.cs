﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankMangementSystem.BLL;
using BloodBankMangementSystem.Entity;
using BloodBankMangementSystem.Exceptions;

namespace BloodBankManagementSystem.UI
{
    /// <summary>
    /// Interaction logic for BloodDonorDonation.xaml
    /// </summary>
    public partial class BloodDonorDonation : Window
    {
        public BloodDonorDonation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

            DonationDetails dd = new DonationDetails();
            dd.ShowDialog();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {




            try
            {
                DonorBL b = new DonorBL();
                if (b.ValidateBloodDonationDetails(txtBloodDonorId.Text, dateChoose.Text, txtnoofbottle.Text, textweight.Text, txtHB.Text))
                {

                    BloodDonorDonations p = new BloodDonorDonations
                    {
                        BloodDonorID = txtBloodDonorId.Text,
                        BloodDonationDate = DateTime.Parse(dateChoose.Text),
                        NumberOfBottles = int.Parse(txtnoofbottle.Text),
                        Weight = int.Parse(textweight.Text),
                        HBCount = decimal.Parse(txtHB.Text)
                    };

                    DonorBL pb = new DonorBL();
                    int pid = pb.AddDonation(p);
                    BloodDonationLabel.Content = pid.ToString();
                    
                    MessageBox.Show(string.Format("New donation added.\ndonation id Id:{0}", pid),
                        "BBMS");
                    clearall();
                }

            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show(ex.Message, "BBMS");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "BBMS");
            }








        }

        public void clearall()
        {
            BloodDonationLabel.Content = null;
            txtBloodDonorId.Text = null;
            txtHB.Text = null;
            txtnoofbottle.Text = null;
            textweight.Text = null;




        }

    }
}
